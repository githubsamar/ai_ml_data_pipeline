# ai_ml_data_pipeline

# AI Articles ETL Pipeline

## Setup
pip install -r requirements.txt

## Run
python pipeline.py

## Output
ai_articles_enriched.csv

## Features
- Data cleaning (revenue, date, category)
- Metadata enrichment
- Embeddings + similarity search
- DuckDB hybrid querying

## Example
from embedding import find_similar_articles
find_similar_articles(df, "AI startup funding", 5)