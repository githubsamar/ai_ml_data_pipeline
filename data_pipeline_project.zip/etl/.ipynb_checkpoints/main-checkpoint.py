import pandas as pd
import enrichment
import embedings
import duckdb_handler
import utils
from cleaningdata import parse_revenue, normalize_date, extract_date_parts, normalize_category

def run_pipeline():
    df = pd.read_csv("./data/input_data/tech_news.csv")
    metadata = pd.read_json("./data/input_data/company_metadata.json")
    
    
    
    df["revenue_usd"] = df["revenue"].apply(parse_revenue)
    
    df["published_date"] = df["published_date"].apply(normalize_date)
    print(df)
    print(df["published_date"].dtype)
    
    df = extract_date_parts(df)
    
    df["category"] = df["category"].apply(normalize_category)

     # Enrichment (join)
    df = df.merge(metadata, on="company_name", how="left")

    df["company_age"] = df.apply(
        lambda x: compute_company_age(x["founded_year"], x["published_date"]), axis=1
    )
    df["company_size_category"] = df["employee_count"].apply(company_size_category)

    # Embeddings
    df = add_embeddings(df)

    # Similarity
    df = add_top_similar(df)

    # Filter
    df = filter_ai_articles(df)

    # Export
    export_csv(df)
    
    print(df)
    print(metadata)


if __name__ == '__main__':
    run_pipeline()
    